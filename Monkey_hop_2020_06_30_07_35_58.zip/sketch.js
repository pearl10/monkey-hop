//Global Variables
var player,player_running;
var banana,bananaImage,bananaGroup;
var obstacle,obstaclesImage,obstaclesGroup;
var backround,backround_running;
var score;
var ground,groundImage;
var edges
function preload(){


player_running=loadAnimation("Monkey_01.png","Monkey_02.png","Monkey_03.png","Monkey_04.png","Monkey_05.png","Monkey_06.png","Monkey_07.png","Monkey_08.png","Monkey_09.png","Monkey_10.png");

backround_running=loadImage("jungle.jpg");

 
  bananaImage = loadImage("Banana.png")


  obstaclesImage = loadImage("stone.png")


}

function setup() {
  createCanvas(600,800);


  backround= createSprite(300,150);
 backround.velocityX=-2

backround.addImage("stop",backround_running );


   
  ground=createSprite(300,300,600,5);
 // ground.addImage("ground",groundImage);
 ground.scale=0.2
//ground.visible = false;
  
  player = createSprite(250,300,20,50);
  player.addAnimation("run",player_running );
  player.scale = 0.2;


 var bananagroup = createGroup();
var obstaclesgroup = createGroup();

}


function draw(){
 edges=createEdgeSprites();
  
  if(backround.x<0){
  backround.x=backround.width/2;   
  backround.scale=1.5;
  }
  if(keyDown("space") ){ 
player.velocityY=-10;
}
  
  
  
  
  
  
  
  
 
  
  player.velocityY=player.velocityY+0.8;
 
player.collide(ground);
  
  spawnObstacles();
  spawnBanana();
  drawSprites();
}

function spawnBanana() {
  //write code here to spawn the clouds
  if(frameCount%60===0){
var banana = createSprite(590,300,10,10);
    banana.y = random(250,300);
    banana.addImage("cloud",bananaImage);
    banana.scale = 0.2;
    banana.velocityX = -3;
banana.lifetime=190 ;  
banana.add("bananaGroup");

}
    
     
  
  
}

function spawnObstacles(){
 if(frameCount%60===0){
var obstacle = createSprite(590,150,10,10);
    obstacle.y = random(250,300);
    obstacle.addImage("cloud",obstaclesImage);
   obstacle.scale = 0.2;
  obstacle .velocityX = -3;
 
obstacle.lifetime=190;   

}


}



